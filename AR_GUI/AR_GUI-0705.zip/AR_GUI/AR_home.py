from tkinter import *
import cv2
from PIL import Image, ImageTk

class basedesk():
    def __init__(self, master):
        self.root = master
        self.root.title('home page')
        self.root.geometry('1200x700+150+50')
        self.root.resizable(False, False)

        self.initface = initface(self.root)

class initface():
    def __init__(self, master):
        self.master = master

        self.surface = PhotoImage(file="main.png")
        bg = Canvas(master, width=1200, height=700)
        bg.create_image(0, 0, anchor=NW, image=self.surface)
        bg.place(x=0, y=0)

        self.initface = Frame(master)
        self.initface.place(x=0, y=0)

        # 创建按钮，将按钮与相应的函数关联
        shop = Button(text='Shop', command=self.shopping)
        shop.config(font=15)
        shop.place(x=0, y=600, width=200, height=100)

        setting = Button(text='Settings', command=self.change)
        setting.config(font=15)
        setting.place(x=200, y=600, width=200, height=100)
        
        play = Button(text='PLAY', font=('Arial', 30), command=self.change)
        play.place(x=900, y=100, width=300, height=100)

        task = Canvas(bg='lightskyblue')
        task.place(x=900, y=300, width=300, height=400)

        task1 = BooleanVar()
        task2 = BooleanVar()
        task3 = BooleanVar()

        mycheckbutton1 = Checkbutton(text='apple', font=('Arial', 30), bg='lightskyblue', var=task1)
        mycheckbutton1.place(x=910, y=320)
        mycheckbutton2 = Checkbutton(text='banana', font=('Arial', 30), bg='lightskyblue', var=task2)
        mycheckbutton2.place(x=910, y=420)
        mycheckbutton3 = Checkbutton(text='orange', font=('Arial', 30), bg='lightskyblue', var=task3)
        mycheckbutton3.place(x=910, y=520)

        task3.set(True)

    def shopping(self,):       
            self.initface.destroy()
            face2(self.master)
    def change(self,):       
        self.initface.destroy()
        face1(self.master)
   
class face2():
    def __init__(self,master):
        self.master = master
        self.face1 = Frame(self.master,)
        self.face1.pack()
        self.img2 = PhotoImage(file="background3.png")
        bg = Canvas(width=1200, height=700)
        bg.create_image(0, 0, image=self.img2)   # 在 Canvas 中放入圖片
        bg.place(x=0,y=0)

        block1 = Canvas(width=300, height=500)
        block1.config(bg='black')
        block1.place(x=50,y=40)
        block2 = Canvas(width=300, height=500)
        block2.config(bg='black')
        block2.place(x=450,y=40)
        block3 = Canvas(width=300, height=500)
        block3.config(bg='black')
        block3.place(x=850,y=40)

        pd1 = Canvas(width=260, height=260)
        pd1.config(bg='white')
        pd1.place(x=70,y=60)
        pd2 = Canvas(width=260, height=260)
        pd2.config(bg='white')
        pd2.place(x=470,y=60)
        pd3 = Canvas(width=260, height=260)
        pd3.config(bg='white')
        pd3.place(x=870,y=60)

        register = Button(text="返回",command=self.back)
        register.config(font=15)
        register.place(x=550,y=600,width=100,height=35)

        log_out = Button(text="登出")
        log_out.config(font=15)
        log_out.place(x=70,y=485,width=260,height=35)

        log_out = Button(text="登出")
        log_out.config(font=15)
        log_out.place(x=470,y=485,width=260,height=35)

        log_out = Button(text="登出")
        log_out.config(font=15)
        log_out.place(x=870,y=485,width=260,height=35)



    
    def back(self):
        self.face1.destroy()
        initface(self.master)


    
   
class face1():
    def __init__(self,master):
        self.master = master
        self.face1 = Frame(self.master,)
        self.face1.pack()
        self.img2 = PhotoImage(file="background3.png")
        bg = Canvas(width=1200, height=700)
        bg.create_image(0, 0, image=self.img2)   # 在 Canvas 中放入圖片
        bg.place(x=0,y=0)

        block = Canvas(width=430, height=600)
        block.config(bg='black')
        block.place(x=385,y=40)

        height = Label(text="新身高")
        height.config(font=20,bg='black',fg='white')
        height.place(x=410,y=350)
        height_in = Entry()
        height_in.place(x=480,y=350,width=110,height=30)

        weight = Label(text="新體重")
        weight.config(font=20,bg='black',fg='white')
        weight.place(x=600,y=350)
        weight_in = Entry()
        weight_in.place(x=670,y=350,width=110,height=30)

        name = Label(text="新暱稱")
        name.config(font=20,bg='black',fg='white')
        name.place(x=410,y=400)
        psw = Label(text="新密碼")
        psw.config(font=20,bg='black',fg='white')
        psw.place(x=410,y=450)
        name_in = Entry()
        name_in.place(x=480,y=400,width=300,height=30)
        psw_in = Entry(text="請輸入密碼")
        psw_in.place(x=480,y=450,width=300,height=30)

        register = Button(text="儲存",command=self.back)
        register.config(font=15)
        register.place(x=480,y=550,width=100,height=35)

        log_out = Button(text="登出",command=self.back)
        log_out.config(font=15)
        log_out.place(x=620,y=550,width=100,height=35)

        self.had1 = PhotoImage(file="icon-1.png")
        self.had2 = PhotoImage(file="icon-2.png")
        self.had3 = PhotoImage(file="icon-3.png")

        self.photo = Button(text="Create new window",command=self.createNewWindow)
        self.photo.place(x=550,y=100,width=100, height=100)
    def one(self):
        self.photo.config(image=self.had1)
    def two(self):
        self.photo.config(image=self.had2)
    def three(self):
        self.photo.config(image=self.had3)
    # def c1(self):
    #     self.photo.config(bg = 'pink')
    # def c2(self):
    #     self.photo.config(bg = 'lightgreen')
    # def c3(self):
    #     self.photo.config(bg = 'gray')

     
    def createNewWindow(self):
        choose_photo = Toplevel(self.face1)
        choose_photo.geometry("300x100+600+250")

        photo1 = Button(choose_photo,          # 按鈕所在視窗
                        image=self.had1,  # 顯示文字
                        command = self.one) # 按下按鈕所執行的函數
        photo2 = Button(choose_photo,          # 按鈕所在視窗
                        image=self.had2,  # 顯示文字
                        command = self.two) # 按下按鈕所執行的函數
        photo3 = Button(choose_photo,          # 按鈕所在視窗
                        image=self.had3,  # 顯示文字
                        command = self.three) # 按下按鈕所執行的函數
        # photo4 = Button(choose_photo,          # 按鈕所在視窗
        #                 bg = 'pink',  # 顯示文字
        #                 command = self.c1) # 按下按鈕所執行的函數
        # photo5 = Button(choose_photo,          # 按鈕所在視窗
        #                 bg = 'lightgreen',  # 顯示文字
        #                 command = self.c2) # 按下按鈕所執行的函數
        # photo6 = Button(choose_photo,          # 按鈕所在視窗
        #                 bg = 'gray',  # 顯示文字
        #                 command = self.c3) # 按下按鈕所執行的函數
        # 以預設方式排版按鈕
        photo1.place(x=0,y=0,width=100,height=100)
        photo2.place(x=100,y=0,width=100,height=100)
        photo3.place(x=200,y=0,width=100,height=100)
        # photo4.place(x=0,y=100,width=100,height=100)
        # photo5.place(x=100,y=100,width=100,height=100)
        # photo6.place(x=200,y=100,width=100,height=100)  

    
    def back(self):
        self.face1.destroy()
        initface(self.master)
    # def open_settings(self):
    #     # 打开新画面（示例）
    #     new_window = Toplevel(self.master)
    #     new_window.title('Settings Page')
    #     new_window.geometry('1200x700+150+50')
    #     self.img2 = PhotoImage(file="background3.png")
    #     bg = Canvas(self, width=1200, height=700)
    #     bg.create_image(0, 0, anchor=NW, image=self.img2)   # 在 Canvas 中放入圖片
    #     bg.place(x=0,y=0)
        # 添加新画面的内容

    def open_play(self):
        # 打开新画面（示例）
        new_window = Toplevel(self.master)
        new_window.title('Play Page')
        new_window.geometry('1200x700+150+50')

        # 添加新画面的内容

if __name__ == '__main__':
    root = Tk()
    app = basedesk(root)
    root.mainloop()
