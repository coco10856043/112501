from tkinter import*
from PIL import Image, ImageTk
import os


class basedesk():
    def __init__(self,master):
        self.root = master
        self.root.config()
        self.root.title('Base page')
        self.root.geometry('1200x700+150+50')
        root.resizable(False,False) #視窗縮放(是/否)
        

        initface(self.root)        
                
class initface():
    def __init__(self,master):
        
        self.master = master
        #基準介面initface
        self.img2 = PhotoImage(file="background3.png")
        bg = Canvas(width=1200, height=700)
        bg.create_image(0, 0, image=self.img2)   # 在 Canvas 中放入圖片
        bg.place(x=0,y=0)
        self.initface = Frame(self.master,)
        self.initface.place()
        block = Canvas(width=430, height=500)
        block.config(bg='black')
        block.place(x=385,y=140)

        act = Label(text="帳號")
        act.config(font=20,bg='black',fg='white')
        act.place(x=420,y=450)
        psw = Label(text="密碼")
        psw.config(font=20,bg='black',fg='white')
        psw.place(x=420,y=500)
        act_in = Entry(text="請輸入使用者帳號")
        act_in.place(x=480,y=450,width=300,height=30)
        psw_in = Entry(text="請輸入密碼")
        psw_in.place(x=480,y=500,width=300,height=30)

        login = Button(text="登入",command=self.login_home)
        login.config(font=15)
        login.place(x=480,y=575,width=100,height=35)
        register = Button(text="我要註冊",command=self.change)
        register.config(font=15)
        register.place(x=620,y=575,width=100,height=35)

        self.img = PhotoImage(file="窩快不行ㄌ-w.png")
        logo = Canvas(width=280, height=200)
        logo.config(bg='black',highlightthickness=0)
        logo.create_image(0, 0, anchor='nw', image=self.img)   # 在 Canvas 中放入圖片
        logo.place(x=420,y=180)
       
        
    def change(self,):       
        self.initface.destroy()
        face1(self.master)

    def login_home(self,):
        self.initface.destroy()
        os.system('python AR_home.py')
        root.destroy()

        
           

class face1():
    def __init__(self,master):
        self.master = master
        self.face1 = Frame(self.master,)
        self.face1.pack()
        self.img2 = PhotoImage(file="background3.png")
        bg = Canvas(width=1200, height=700)
        bg.create_image(0, 0, image=self.img2)   # 在 Canvas 中放入圖片
        bg.place(x=0,y=0)

        block = Canvas(width=430, height=600)
        block.config(bg='black')
        block.place(x=385,y=40)

        gender = Label(text="性別")
        gender.config(font=20,bg='black',fg='white')
        gender.place(x=420,y=300)

        self.var = IntVar()  # 這邊的性別單選格無法固定
        gender_girl = Radiobutton(text='女', font=20, fg='white', bg='black', variable=self.var, value="女")  # 放入第一个单选按钮
        gender_girl.place(x=480, y=300)
        gender_girl.select()
        gender_boy = Radiobutton(text='男', font=20, fg='white', bg='black', variable=self.var, value="男")  # 放入第二个单选按钮
        gender_boy.place(x=580, y=300)

        height = Label(text="身高")
        height.config(font=20,bg='black',fg='white')
        height.place(x=420,y=350)
        height_in = Entry()
        height_in.place(x=480,y=350,width=110,height=30)

        weight = Label(text="體重")
        weight.config(font=20,bg='black',fg='white')
        weight.place(x=610,y=350)
        weight_in = Entry()
        weight_in.place(x=670,y=350,width=110,height=30)

        name = Label(text="暱稱")
        name.config(font=20,bg='black',fg='white')
        name.place(x=420,y=400)
        act = Label(text="帳號")
        act.config(font=20,bg='black',fg='white')
        act.place(x=420,y=450)
        psw = Label(text="密碼")
        psw.config(font=20,bg='black',fg='white')
        psw.place(x=420,y=500)
        name_in = Entry()
        name_in.place(x=480,y=400,width=300,height=30)
        act_in = Entry()
        act_in.place(x=480,y=450,width=300,height=30)
        psw_in = Entry(text="請輸入密碼")
        psw_in.place(x=480,y=500,width=300,height=30)

        register = Button(text="註冊",command=self.back)
        register.config(font=15)
        register.place(x=550,y=575,width=100,height=35)

        self.had1 = PhotoImage(file="icon-1.png")
        self.had2 = PhotoImage(file="icon-2.png")
        self.had3 = PhotoImage(file="icon-3.png")

        self.photo = Button(text="Create new window",command=self.createNewWindow)
        self.photo.place(x=550,y=100,width=100, height=100)
    def one(self):
        self.photo.config(image=self.had1)
    def two(self):
        self.photo.config(image=self.had2)
    def three(self):
        self.photo.config(image=self.had3)
    # def c1(self):
    #     self.photo.config(bg = 'pink')
    # def c2(self):
    #     self.photo.config(bg = 'lightgreen')
    # def c3(self):
    #     self.photo.config(bg = 'gray')

     
    def createNewWindow(self):
        choose_photo = Toplevel(self.face1)
        choose_photo.geometry("300x100+600+250")

        photo1 = Button(choose_photo,          # 按鈕所在視窗
                        image=self.had1,  # 顯示文字
                        command = self.one) # 按下按鈕所執行的函數
        photo2 = Button(choose_photo,          # 按鈕所在視窗
                        image=self.had2,  # 顯示文字
                        command = self.two) # 按下按鈕所執行的函數
        photo3 = Button(choose_photo,          # 按鈕所在視窗
                        image=self.had3,  # 顯示文字
                        command = self.three) # 按下按鈕所執行的函數
        # photo4 = Button(choose_photo,          # 按鈕所在視窗
        #                 bg = 'pink',  # 顯示文字
        #                 command = self.c1) # 按下按鈕所執行的函數
        # photo5 = Button(choose_photo,          # 按鈕所在視窗
        #                 bg = 'lightgreen',  # 顯示文字
        #                 command = self.c2) # 按下按鈕所執行的函數
        # photo6 = Button(choose_photo,          # 按鈕所在視窗
        #                 bg = 'gray',  # 顯示文字
        #                 command = self.c3) # 按下按鈕所執行的函數
        # 以預設方式排版按鈕
        photo1.place(x=0,y=0,width=100,height=100)
        photo2.place(x=100,y=0,width=100,height=100)
        photo3.place(x=200,y=0,width=100,height=100)
        # photo4.place(x=0,y=100,width=100,height=100)
        # photo5.place(x=100,y=100,width=100,height=100)
        # photo6.place(x=200,y=100,width=100,height=100)  

    
    def back(self):
        self.face1.destroy()
        initface(self.master)
        
    
if __name__ == '__main__':    
    root = Tk()
    basedesk(root)
    root.mainloop()