from tkinter import*

root = Tk()
root.title('oxxo.studio')

surface = PhotoImage(file="主介面.png")
bg = Canvas(width=1200, height=700)
bg.create_image(0, 0, image=surface)   # 在 Canvas 中放入圖片
bg.place(x=0,y=0)

root.mainloop()