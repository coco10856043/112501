import tkinter as tk
from tkinter import StringVar, ttk
from Calendar import Calendar



class MainPage:
    def __init__(self,master:tk.Tk):
        self.root = master
        self.root.title('车牌管理系统 V0.0.1')
        self.root.geometry('200x300')
        self.start_date = StringVar()
        self.end_date = StringVar()
        # frame1 = tk.Frame(self.root)