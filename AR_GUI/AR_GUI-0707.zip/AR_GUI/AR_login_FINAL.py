from tkinter import*
import tkinter.ttk as tt
from tkcalendar import Calendar
import datetime
import os


class basedesk():
    def __init__(self,master):
        self.root = master
        self.root.config()
        self.root.title('Base page')
        self.root.geometry('1200x700+150+50')
        root.resizable(False,False) #視窗縮放(是/否)
        

        initface(self.root)        
                
class initface():
    def __init__(self,master):
        
        self.master = master
        # 登入底圖
        self.img2 = PhotoImage(file="background3.png")
        bg = Canvas(width=1200, height=700)
        bg.create_image(0, 0, image=self.img2)   # 在 Canvas 中放入圖片
        bg.place(x=0,y=0)

        self.initface = Frame(self.master,)
        self.initface.place()
        # 登入區塊
        block = Canvas(width=430, height=500)
        block.config(bg='black')
        block.place(x=385,y=140)

        def on_entry_click_a(event):
            if act_in.get() == '請輸入帳號':
                act_in.delete(0, "end")  # 刪除現有文本
                act_in.insert(0, '')  # 插入一個空字符串，以便不顯示灰色文本
                act_in.config(fg='black')  # 將文本顏色設置為黑色

        def on_focus_out_a(event):
            if act_in.get() == '':
                act_in.insert(0, '請輸入帳號')
                act_in.config(fg='grey')  # 將文本顏色設置為灰色

        act = Label(text="帳號")
        act.config(font=20,bg='black',fg='white')
        act.place(x=420,y=450)
        act_in = Entry(root, fg='grey', width=30)
        act_in.insert(0, '請輸入帳號')
        act_in.bind('<FocusIn>', on_entry_click_a)
        act_in.bind('<FocusOut>', on_focus_out_a)
        act_in.place(x=480,y=450,width=300,height=30)
        # act_in = Entry(text="請輸入使用者帳號")
        # act_in.place(x=480,y=450,width=300,height=30)

        def on_entry_click_p(event):
            if psw_in.get() == '請輸入密碼':
                psw_in.delete(0, "end")  # 刪除現有文本
                psw_in.insert(0, '')  # 插入一個空字符串，以便不顯示灰色文本
                psw_in.config(fg='black')  # 將文本顏色設置為黑色

        def on_focus_out_p(event):
            if psw_in.get() == '':
                psw_in.insert(0, '請輸入密碼')
                psw_in.config(fg='grey')  # 將文本顏色設置為灰色

        psw = Label(text="密碼")
        psw.config(font=20,bg='black',fg='white')
        psw.place(x=420,y=500)
        psw_in = Entry(root, fg='grey', width=30)
        psw_in.insert(0, '請輸入密碼')
        psw_in.bind('<FocusIn>', on_entry_click_p)
        psw_in.bind('<FocusOut>', on_focus_out_p)
        psw_in.place(x=480,y=500,width=300,height=30)

        login = Button(text="登入",command=self.login_home)
        login.config(font=15)
        login.place(x=480,y=575,width=100,height=35)
        register = Button(text="我要註冊",command=self.change)
        register.config(font=15)
        register.place(x=620,y=575,width=100,height=35)
        # logo
        self.img = PhotoImage(file="窩快不行ㄌ-w.png")
        logo = Canvas(width=280, height=200)
        logo.config(bg='black',highlightthickness=0)
        logo.create_image(0, 0, anchor='nw', image=self.img)   # 在 Canvas 中放入圖片
        logo.place(x=420,y=180)
       
        
    def change(self,):       
        self.initface.destroy()
        face1(self.master)

    def login_home(self,):
        self.initface.destroy()
        root.destroy()
        os.system('python AR_home.py')
        

class face1():
    def __init__(self,master):
        self.master = master
        self.face1 = Frame(self.master,)
        self.face1.pack()
        # 註冊底圖
        self.img2 = PhotoImage(file="background3.png")
        bg = Canvas(width=1200, height=700)
        bg.create_image(0, 0, image=self.img2)   # 在 Canvas 中放入圖片
        bg.place(x=0,y=0)
        # 註冊區塊
        block = Canvas(width=430, height=600)
        block.config(bg='black')
        block.place(x=385,y=40)

        gender = Label(text="性別")
        gender.config(font=20,bg='black',fg='white')
        gender.place(x=420,y=300)
        # 這邊性別做三種，如果影響到資料庫可以直接刪成兩個
        stdGrade = ('男','女','保密')

        comGrade = tt.Combobox(width=50, values=stdGrade)
        comGrade.place(x=480, y=300, width=50, height=30)

        def on_entry_click_h(event):
            if height_in.get() == '請輸入身高（公分）':
                height_in.delete(0, "end")  # 刪除現有文本
                height_in.insert(0, '')  # 插入一個空字符串，以便不顯示灰色文本
                height_in.config(fg='black')  # 將文本顏色設置為黑色

        def on_focus_out_h(event):
            if height_in.get() == '':
                height_in.insert(0, '請輸入身高（公分）')
                height_in.config(fg='grey')  # 將文本顏色設置為灰色

        height = Label(text="身高")
        height.config(font=20,bg='black',fg='white')
        height.place(x=420,y=350)
        height_in = Entry(root, fg='grey', width=30)
        height_in.insert(0, '請輸入身高（公分）')
        height_in.bind('<FocusIn>', on_entry_click_h)
        height_in.bind('<FocusOut>', on_focus_out_h)
        height_in.place(x=480,y=350,width=110,height=30)


        def on_entry_click_w(event):
            if weight_in.get() == '請輸入體重（公斤）':
                weight_in.delete(0, "end")  # 刪除現有文本
                weight_in.insert(0, '')  # 插入一個空字符串，以便不顯示灰色文本
                weight_in.config(fg='black')  # 將文本顏色設置為黑色

        def on_focus_out_w(event):
            if weight_in.get() == '':
                weight_in.insert(0, '請輸入體重（公斤）')
                weight_in.config(fg='grey')  # 將文本顏色設置為灰色

        weight = Label(text="體重")
        weight.config(font=20,bg='black',fg='white')
        weight.place(x=610,y=350)
        weight_in = Entry(root, fg='grey', width=30)
        weight_in.insert(0, '請輸入體重（公斤）')
        weight_in.bind('<FocusIn>', on_entry_click_w)
        weight_in.bind('<FocusOut>', on_focus_out_w)
        weight_in.place(x=670,y=350,width=110,height=30)
        # weight_in = Entry()
        # weight_in.place(x=670,y=350,width=110,height=30)

        name = Label(text="生日")
        name.config(font=20, bg='black', fg='white')
        name.place(x=420, y=400)

        def start_calendar():
            def print_sel():
                selected_date = cal.get_date()
                # selected_time = f"{hour.get()}:{minute.get()}"
                start_time_text.delete(0, END)
                start_time_text.insert(0, f"{selected_date} ")
                top.destroy()  # 關閉日期選擇視窗

            top = Toplevel()
            top.geometry("300x250")

            today = datetime.date.today()

            mindate = datetime.date(year=1999, month=1, day=1)
            maxdate = today + datetime.timedelta(days=5)
            # 日期選擇視窗裡面的配色等外面圖換好可以改
            cal = Calendar(top, font="Arial 14", selectmode='day', locale='zh_CN', mindate=mindate, maxdate=maxdate,
                        background="red", foreground="blue", bordercolor="red", selectbackground="red",
                        selectforeground="red", disabledselectbackground=False)
            cal.place(x=0, y=0, width=300, height=200)
        
            Button(top, text="確定", command=print_sel).place(x=240, y=205)

        start_time = Button(text="選擇日期", command=start_calendar)
        start_time.place(x=480,y=400)
        start_time_text = Entry(width=20)
        start_time_text.place(x=550,y=400,width=230,height=30)

        def on_entry_click_a(event):
            if act_in.get() == '請輸入帳號':
                act_in.delete(0, "end")  # 刪除現有文本
                act_in.insert(0, '')  # 插入一個空字符串，以便不顯示灰色文本
                act_in.config(fg='black')  # 將文本顏色設置為黑色

        def on_focus_out_a(event):
            if act_in.get() == '':
                act_in.insert(0, '請輸入帳號')
                act_in.config(fg='grey')  # 將文本顏色設置為灰色

        act = Label(text="帳號")
        act.config(font=20, bg='black', fg='white')
        act.place(x=420, y=450)
        act_in = Entry(root, fg='grey', width=30)
        act_in.insert(0, '請輸入帳號')
        act_in.bind('<FocusIn>', on_entry_click_a)
        act_in.bind('<FocusOut>', on_focus_out_a)
        act_in.place(x=480,y=450,width=300,height=30)
        # act_in = Entry()
        # act_in.place(x=480,y=450,width=300,height=30)

        def on_entry_click_p(event):
            if psw_in.get() == '請輸入密碼':
                psw_in.delete(0, "end")  # 刪除現有文本
                psw_in.insert(0, '')  # 插入一個空字符串，以便不顯示灰色文本
                psw_in.config(fg='black')  # 將文本顏色設置為黑色

        def on_focus_out_p(event):
            if psw_in.get() == '':
                psw_in.insert(0, '請輸入密碼')
                psw_in.config(fg='grey')  # 將文本顏色設置為灰色
        
        psw = Label(text="密碼")
        psw.config(font=20,bg='black',fg='white')
        psw.place(x=420,y=500)
        psw_in = Entry(root, fg='grey', width=30)
        psw_in.insert(0, '請輸入密碼')
        psw_in.bind('<FocusIn>', on_entry_click_p)
        psw_in.bind('<FocusOut>', on_focus_out_p)
        psw_in.place(x=480,y=500,width=300,height=30)

        register = Button(text="註冊",command=self.back)
        register.config(font=15)
        register.place(x=550,y=575,width=100,height=35)

        self.had1 = PhotoImage(file="icon-1.png")
        self.had2 = PhotoImage(file="icon-2.png")
        self.had3 = PhotoImage(file="icon-3.png")

        self.photo = Button(text="Create new window",command=self.createNewWindow)
        self.photo.place(x=550,y=100,width=100, height=100)
    def one(self):
        self.photo.config(image=self.had1)
    def two(self):
        self.photo.config(image=self.had2)
    def three(self):
        self.photo.config(image=self.had3)
     
    def createNewWindow(self):
        choose_photo = Toplevel(self.face1)
        choose_photo.geometry("300x100+600+250")

        photo1 = Button(choose_photo,          # 按鈕所在視窗
                        image=self.had1,  # 顯示文字
                        command = self.one) # 按下按鈕所執行的函數
        photo2 = Button(choose_photo,          # 按鈕所在視窗
                        image=self.had2,  # 顯示文字
                        command = self.two) # 按下按鈕所執行的函數
        photo3 = Button(choose_photo,          # 按鈕所在視窗
                        image=self.had3,  # 顯示文字
                        command = self.three) # 按下按鈕所執行的函數

        # 以預設方式排版按鈕
        photo1.place(x=0,y=0,width=100,height=100)
        photo2.place(x=100,y=0,width=100,height=100)
        photo3.place(x=200,y=0,width=100,height=100)

    
    def back(self):
        self.face1.destroy()
        initface(self.master)
        
    
if __name__ == '__main__':    
    root = Tk()
    basedesk(root)
    root.mainloop()