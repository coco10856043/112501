from tkinter import *
import cv2
from PIL import Image, ImageTk
import os
import matplotlib.pyplot as plt

class basedesk():
    def __init__(self, master):
        self.rot = master
        self.rot.title('AR SPORTS WORLD')
        self.rot.geometry('1200x700+150+50')
        self.rot.resizable(False, False)

        self.initface = initface(self.rot)

class initface():
    def __init__(self, master):
        self.master = master

        self.surface = PhotoImage(file="background3.png")
        bg = Canvas(master, width=1200, height=700)
        bg.create_image(0, 0, anchor=NW, image=self.surface)
        bg.create_text(370,70,text='★英雄榜★',font=('微軟正黑體',50,'bold'),fill='white')
        bg.create_text(540,150,text='用戶名1',font=('微軟正黑體',30,'bold'),fill='white')
        bg.create_text(540,200,text='用戶名2',font=('微軟正黑體',30,'bold'),fill='white')
        bg.create_text(540,250,text='用戶名3',font=('微軟正黑體',30,'bold'),fill='white')
        bg.create_text(540,300,text='用戶名4',font=('微軟正黑體',30,'bold'),fill='white')
        bg.create_text(540,350,text='用戶名5',font=('微軟正黑體',30,'bold'),fill='white')

        bg.create_text(200,150,text='NO.1',font=('微軟正黑體',30,'bold'),fill='white')
        bg.create_text(200,200,text='NO.2',font=('微軟正黑體',30,'bold'),fill='white')
        bg.create_text(200,250,text='NO.3',font=('微軟正黑體',30,'bold'),fill='white')
        bg.create_text(200,300,text='NO.4',font=('微軟正黑體',30,'bold'),fill='white')
        bg.create_text(200,350,text='NO.5',font=('微軟正黑體',30,'bold'),fill='white')
        bg.place(x=0, y=0)

        self.initface = Frame(master)
        self.initface.place(x=0, y=0)

        # 排行榜入榜頭像(這邊需要40*40版的頭像)
        r_had1 = Canvas()
        r_had1.place(x=420, y=130, width=40, height=40)
        r_had2 = Canvas()
        r_had2.place(x=420, y=180, width=40, height=40)
        r_had3 = Canvas()
        r_had3.place(x=420, y=230, width=40, height=40)
        r_had4 = Canvas()
        r_had4.place(x=420, y=280, width=40, height=40)
        r_had5 = Canvas()
        r_had5.place(x=420, y=330, width=40, height=40)


        # 商店按鈕(缺底圖)
        shop = Button(text='Shop', command=self.shopping)
        shop.config(font=15)
        shop.place(x=0, y=500, width=200, height=200)

        # 設定按鈕(缺底圖)
        setting = Button(text='Settings', command=self.change)
        setting.config(font=15)
        setting.place(x=200, y=500, width=200, height=200)
        
        # PLAY按鈕(缺底圖)
        play = Button(text='PLAY', font=('Arial', 30), command=self.PLAY)
        play.place(x=850, y=50, width=350, height=100)

        # 圖表部分
        def show_chart():
            x = [1, 2, 3, 4, 5]
            y = [10, 8, 15, 12, 7]
            
            plt.figure(figsize=(6, 4))
            plt.plot(x, y, marker='o', linestyle='-', color='b')
            plt.title("示例图表")
            plt.xlabel("X轴")
            plt.ylabel("Y轴")
            plt.grid()
            plt.show()

        # 圖表顯示鈕(缺底圖)
        show_chart = Button(text='SHOW CHART', font=('Arial', 20), command=show_chart)
        show_chart.place(x=950, y=170, width=250, height=50)

        # 任務區塊(缺底圖)
        task = Canvas(bg='lightskyblue')
        task.place(x=900, y=300, width=300, height=400)

        # 任務內容
        task1 = BooleanVar()
        task2 = BooleanVar()
        task3 = BooleanVar()
        mycheckbutton1 = Checkbutton(text='apple', font=('Arial', 30), bg='lightskyblue', var=task1)
        mycheckbutton1.place(x=910, y=320)
        mycheckbutton2 = Checkbutton(text='banana', font=('Arial', 30), bg='lightskyblue', var=task2)
        mycheckbutton2.place(x=910, y=420)
        mycheckbutton3 = Checkbutton(text='orange', font=('Arial', 30), bg='lightskyblue', var=task3)
        mycheckbutton3.place(x=910, y=520)

        task3.set(True)

    # 商店跳轉
    def shopping(self,):       
        self.initface.destroy()
        face2(self.master)

    # 設定跳轉
    def change(self,):       
        self.initface.destroy()
        face1(self.master)
    # PLAY跳轉
    def PLAY(self,):       
        self.initface.destroy()
        face3(self.master)
# 商店頁
class face2():
    def __init__(self,master):
        self.master = master
        self.face1 = Frame(self.master,)
        self.face1.pack()
        # 底圖
        self.img2 = PhotoImage(file="background3.png")
        bg = Canvas(width=1200, height=700)
        bg.create_image(0, 0, image=self.img2)   # 在 Canvas 中放入圖片
        bg.place(x=0,y=0)

        # 商品區塊
        block1 = Canvas(width=300, height=500)
        block1.config(bg='black')
        block1.place(x=50,y=40)
        block2 = Canvas(width=300, height=500)
        block2.config(bg='black')
        block2.place(x=450,y=40)
        block3 = Canvas(width=300, height=500)
        block3.config(bg='black')
        block3.place(x=850,y=40)
        # 商品圖(缺)
        pd1 = Canvas(width=260, height=260)
        pd1.config(bg='white')
        pd1.place(x=70,y=60)
        pd2 = Canvas(width=260, height=260)
        pd2.config(bg='white')
        pd2.place(x=470,y=60)
        pd3 = Canvas(width=260, height=260)
        pd3.config(bg='white')
        pd3.place(x=870,y=60)
        # 返回鈕
        register = Button(text="返回",command=self.back)
        register.config(font=15)
        register.place(x=550,y=600,width=100,height=35)
        # 購買鈕
        buy1 = Button(text="購買")
        buy1.config(font=15)
        buy1.place(x=70,y=485,width=260,height=35)
        buy2 = Button(text="購買")
        buy2.config(font=15)
        buy2.place(x=470,y=485,width=260,height=35)
        buy3 = Button(text="購買")
        buy3.config(font=15)
        buy3.place(x=870,y=485,width=260,height=35)

    # 反回主頁方法
    def back(self):
        self.face1.destroy()
        initface(self.master)
# 設定頁
class face1():
    def __init__(self,master):
        self.master = master
        self.face1 = Frame(self.master,)
        self.face1.pack()
        # 底圖
        self.img2 = PhotoImage(file="background3.png")
        bg = Canvas(width=1200, height=700)
        bg.create_image(0, 0, image=self.img2)   # 在 Canvas 中放入圖片
        bg.place(x=0,y=0)
        # 設定區塊
        block = Canvas(width=430, height=600)
        block.config(bg='black')
        block.place(x=385,y=40)

        def on_entry_click_h(event):
            if height_in.get() == '請輸入身高（公分）':
                height_in.delete(0, "end")  # 刪除現有文本
                height_in.insert(0, '')  # 插入一個空字符串，以便不顯示灰色文本
                height_in.config(fg='black')  # 將文本顏色設置為黑色

        def on_focus_out_h(event):
            if height_in.get() == '':
                height_in.insert(0, '請輸入身高（公分）')
                height_in.config(fg='grey')  # 將文本顏色設置為灰色

        height = Label(text="新身高")
        height.config(font=20,bg='black',fg='white')
        height.place(x=410,y=350)
        height_in = Entry(rot, fg='grey', width=30)
        height_in.insert(0, '請輸入身高（公分）')
        height_in.bind('<FocusIn>', on_entry_click_h)
        height_in.bind('<FocusOut>', on_focus_out_h)
        height_in.place(x=480,y=350,width=110,height=30)

        def on_entry_click_w(event):
            if weight_in.get() == '請輸入體重（公斤）':
                weight_in.delete(0, "end")  # 刪除現有文本
                weight_in.insert(0, '')  # 插入一個空字符串，以便不顯示灰色文本
                weight_in.config(fg='black')  # 將文本顏色設置為黑色

        def on_focus_out_w(event):
            if weight_in.get() == '':
                weight_in.insert(0, '請輸入體重（公斤）')
                weight_in.config(fg='grey')  # 將文本顏色設置為灰色

        weight = Label(text="新體重")
        weight.config(font=20,bg='black',fg='white')
        weight.place(x=600,y=350)
        weight_in = Entry(rot, fg='grey', width=30)
        weight_in.insert(0, '請輸入體重（公斤）')
        weight_in.bind('<FocusIn>', on_entry_click_w)
        weight_in.bind('<FocusOut>', on_focus_out_w)
        weight_in.place(x=670,y=350,width=110,height=30)

        def on_entry_click_n(event):
            if name_in.get() == '請輸入暱稱':
                name_in.delete(0, "end")  # 刪除現有文本
                name_in.insert(0, '')  # 插入一個空字符串，以便不顯示灰色文本
                name_in.config(fg='black')  # 將文本顏色設置為黑色

        def on_focus_out_n(event):
            if name_in.get() == '':
                name_in.insert(0, '請輸入暱稱')
                name_in.config(fg='grey')  # 將文本顏色設置為灰色

        name = Label(text="新暱稱")
        name.config(font=20,bg='black',fg='white')
        name.place(x=410,y=400)
        name_in = Entry(rot, fg='grey', width=30)
        name_in.insert(0, '請輸入暱稱')
        name_in.bind('<FocusIn>', on_entry_click_n)
        name_in.bind('<FocusOut>', on_focus_out_n)
        name_in.place(x=480,y=400,width=300,height=30)

        def on_entry_click_p(event):
            if psw_in.get() == '請輸入密碼':
                psw_in.delete(0, "end")  # 刪除現有文本
                psw_in.insert(0, '')  # 插入一個空字符串，以便不顯示灰色文本
                psw_in.config(fg='black')  # 將文本顏色設置為黑色

        def on_focus_out_p(event):
            if psw_in.get() == '':
                psw_in.insert(0, '請輸入密碼')
                psw_in.config(fg='grey')  # 將文本顏色設置為灰色

        psw = Label(text="新密碼")
        psw.config(font=20,bg='black',fg='white')
        psw.place(x=410,y=450)
        psw_in = Entry(rot, fg='grey', width=30)
        psw_in.insert(0, '請輸入密碼')
        psw_in.bind('<FocusIn>', on_entry_click_p)
        psw_in.bind('<FocusOut>', on_focus_out_p)
        psw_in.place(x=480,y=450,width=300,height=30)

        register = Button(text="儲存",command=self.back)
        register.config(font=15)
        register.place(x=480,y=550,width=100,height=35)

        log_out = Button(text="登出",command=self.log_out)
        log_out.config(font=15)
        log_out.place(x=620,y=550,width=100,height=35)

        self.had1 = PhotoImage(file="icon-1.png")
        self.had2 = PhotoImage(file="icon-2.png")
        self.had3 = PhotoImage(file="icon-3.png")

        self.photo = Button(text="Create new window",command=self.createNewWindow)
        self.photo.place(x=550,y=100,width=100, height=100)

        self.g_photo1 = Button(text="choose game1 photo",command=self.g1_photo)
        self.g_photo1.place(x=430,y=220,width=100, height=100)
        self.g_photo2 = Button(text="choose game2 photo",command=self.g2_photo)
        self.g_photo2.place(x=550,y=220,width=100, height=100)
        self.g_photo3 = Button(text="choose game3 photo",command=self.g3_photo)
        self.g_photo3.place(x=670,y=220,width=100, height=100)
        

    def one(self):
        self.photo.config(image=self.had1)
    def two(self):
        self.photo.config(image=self.had2)
    def three(self):
        self.photo.config(image=self.had3)
    # def login_home(self,):
    #     self.initface.destroy()
    #     os.system('python AR_login_FINAL.py')
    #     rot.destroy()
    #頭像 
    def createNewWindow(self):
        choose_photo = Toplevel(self.face1)
        choose_photo.title = ('choose_photo')
        choose_photo.geometry("300x100+600+250")

        photo1 = Button(choose_photo,          # 按鈕所在視窗
                        image=self.had1,  # 顯示文字
                        command = self.one) # 按下按鈕所執行的函數
        photo2 = Button(choose_photo,          # 按鈕所在視窗
                        image=self.had2,  # 顯示文字
                        command = self.two) # 按下按鈕所執行的函數
        photo3 = Button(choose_photo,          # 按鈕所在視窗
                        image=self.had3,  # 顯示文字
                        command = self.three) # 按下按鈕所執行的函數

        # 頭像選擇按鈕
        photo1.place(x=0,y=0,width=100,height=100)
        photo2.place(x=100,y=0,width=100,height=100)
        photo3.place(x=200,y=0,width=100,height=100)

#遊戲一
    def g1_one(self):
        self.g_photo1.config(image=self.had1)
    def g1_two(self):
        self.g_photo1.config(image=self.had2)
    def g1_three(self):
        self.g_photo1.config(image=self.had3)

    
    def g1_photo(self):
        choose_photog1 = Toplevel(self.face1)
        choose_photog1.title = ('choose_photo')
        choose_photog1.geometry("300x100+600+250")

        photo1 = Button(choose_photog1,          # 按鈕所在視窗
                        image=self.had1,  # 顯示文字
                        command = self.g1_one) # 按下按鈕所執行的函數
        photo2 = Button(choose_photog1,          # 按鈕所在視窗
                        image=self.had2,  # 顯示文字
                        command = self.g1_two) # 按下按鈕所執行的函數
        photo3 = Button(choose_photog1,          # 按鈕所在視窗
                        image=self.had3,  # 顯示文字
                        command = self.g1_three) # 按下按鈕所執行的函數

        # 頭像選擇按鈕
        photo1.place(x=0,y=0,width=100,height=100)
        photo2.place(x=100,y=0,width=100,height=100)
        photo3.place(x=200,y=0,width=100,height=100)

#遊戲二      
    def g2_one(self):
        self.g_photo2.config(image=self.had1)
    def g2_two(self):
        self.g_photo2.config(image=self.had2)
    def g2_three(self):
        self.g_photo2.config(image=self.had3)


    def g2_photo(self):
        choose_photog2 = Toplevel(self.face1)
        choose_photog2.title = ('choose_photo')
        choose_photog2.geometry("300x100+600+250")

        photo1 = Button(choose_photog2,          # 按鈕所在視窗
                        image=self.had1,  # 顯示文字
                        command = self.g2_one) # 按下按鈕所執行的函數
        photo2 = Button(choose_photog2,          # 按鈕所在視窗
                        image=self.had2,  # 顯示文字
                        command = self.g2_two) # 按下按鈕所執行的函數
        photo3 = Button(choose_photog2,          # 按鈕所在視窗
                        image=self.had3,  # 顯示文字
                        command = self.g2_three) # 按下按鈕所執行的函數

        # 頭像選擇按鈕
        photo1.place(x=0,y=0,width=100,height=100)
        photo2.place(x=100,y=0,width=100,height=100)
        photo3.place(x=200,y=0,width=100,height=100)
        
#遊戲三 
    def g3_one(self):
        self.g_photo3.config(image=self.had1)
    def g3_two(self):
        self.g_photo3.config(image=self.had2)
    def g3_three(self):
        self.g_photo3.config(image=self.had3)


    def g3_photo(self):
        choose_photog3 = Toplevel(self.face1)
        choose_photog3.title = ('choose_photo')
        choose_photog3.geometry("300x100+600+250")

        photo1 = Button(choose_photog3,          # 按鈕所在視窗
                        image=self.had1,  # 顯示文字
                        command = self.g3_one) # 按下按鈕所執行的函數
        photo2 = Button(choose_photog3,          # 按鈕所在視窗
                        image=self.had2,  # 顯示文字
                        command = self.g3_two) # 按下按鈕所執行的函數
        photo3 = Button(choose_photog3,          # 按鈕所在視窗
                        image=self.had3,  # 顯示文字
                        command = self.g3_three) # 按下按鈕所執行的函數

        # 頭像選擇按鈕
        photo1.place(x=0,y=0,width=100,height=100)
        photo2.place(x=100,y=0,width=100,height=100)
        photo3.place(x=200,y=0,width=100,height=100)

    # 回首頁方法
    def back(self):
        self.face1.destroy()
        initface(self.master)
    # 登出(回到登入頁面)
    def log_out(self):
        rot.destroy()
        os.system('python AR_login_FINAL.py')

# PLAY頁面
class face3():
    def __init__(self,master):
        self.master = master
        self.face1 = Frame(self.master,)
        self.face1.pack()
        # 這個canva是放來隔著的，之後如果相機開得起來的話可以刪掉應該沒關西
        bg = Canvas(width=1200, height=700)
        bg.place(x=0,y=0)

    # 反回主頁方法，記得做按鈕
    def back(self):
        self.face3.destroy()
        initface(self.master)


if __name__ == '__main__':
    rot = Tk()
    app = basedesk(rot)
    rot.mainloop()
