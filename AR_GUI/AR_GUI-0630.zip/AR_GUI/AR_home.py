from tkinter import*
from PIL import Image, ImageTk



class basedesk():
    def __init__(self,master):
        self.root = master
        self.root.config()
        self.root.title('home page')
        self.root.geometry('1200x700+150+50')
        root.resizable(False,False) #視窗縮放(是/否)
        

        initface(self.root)        
                
class initface():
    def __init__(self,master):
        
        self.master = master
        #基準介面initface
        self.img2 = PhotoImage(file="background3.png")
        bg = Canvas(width=1200, height=700)
        bg.create_image(0, 0, image=self.img2)   # 在 Canvas 中放入圖片
        bg.place(x=0,y=0)
        self.initface = Frame(self.master,)
        self.initface.place()
        # block = Canvas(width=430, height=500)
        # block.config(bg='black')
        # block.place(x=385,y=140)

        # act = Label(text="帳號")
        # act.config(font=20,bg='black',fg='white')
        # act.place(x=420,y=450)
        # psw = Label(text="密碼")
        # psw.config(font=20,bg='black',fg='white')
        # psw.place(x=420,y=500)
        # act_in = Entry(text="請輸入使用者帳號")
        # act_in.place(x=480,y=450,width=300,height=30)
        # psw_in = Entry(text="請輸入密碼")
        # psw_in.place(x=480,y=500,width=300,height=30)

        shop = Button()
        shop.config(font=15)
        shop.place(x=0,y=600,width=100,height=100)
        setting = Button()
        setting.config(font=15)
        setting.place(x=100,y=600,width=100,height=100)
        play = Button()
        play.config(font=15)
        play.place(x=900,y=150,width=300,height=100)
        

        self.img = PhotoImage(file="窩快不行ㄌ-w.png")
        logo = Canvas(width=280, height=200)
        logo.config(bg='black',highlightthickness=0)
        logo.create_image(0, 0, anchor='nw', image=self.img)   # 在 Canvas 中放入圖片
        logo.place(x=420,y=180)
       
        
    def change(self,):       
        self.initface.destroy()
        face1(self.master)      

class face1():
    def __init__(self,master):
        self.master = master
        self.face1 = Frame(self.master,)
        self.face1.pack()
        self.img2 = PhotoImage(file="background3.png")
        bg = Canvas(width=1200, height=700)
        bg.create_image(0, 0, image=self.img2)   # 在 Canvas 中放入圖片
        bg.place(x=0,y=0)

        block = Canvas(width=430, height=600)
        block.config(bg='black')
        block.place(x=385,y=40)



        register = Button(text="註冊",command=self.back)
        register.config(font=15)
        register.place(x=550,y=575,width=100,height=35)

        self.photo = Button(text="Create new window",command=self.createNewWindow)
        self.photo.place(x=500,y=100,width=200, height=200)
    def pink(self):
        self.photo.config(bg='pink')
    def orangered(self):
        self.photo.config(bg='orangered')
    def hello(self):
        self.photo.config(bg='orangered')


     
    def createNewWindow(self):
        choose_photo = Toplevel(self.face1)
        choose_photo.geometry("300x200+600+250")

        photo1 = Button(choose_photo,          # 按鈕所在視窗
                        bg='pink',  # 顯示文字
                        command = self.pink) # 按下按鈕所執行的函數
        photo2 = Button(choose_photo,          # 按鈕所在視窗
                            bg='orangered',  # 顯示文字
                            command = self.orangered) # 按下按鈕所執行的函數
        photo3 = Button(choose_photo,          # 按鈕所在視窗
                        bg='sienna',  # 顯示文字
                        command = self.hello) # 按下按鈕所執行的函數
        photo4 = Button(choose_photo,          # 按鈕所在視窗
                        bg = 'skyblue',  # 顯示文字
                        command = self.hello) # 按下按鈕所執行的函數
        photo5 = Button(choose_photo,          # 按鈕所在視窗
                        bg = 'lightgreen',  # 顯示文字
                        command = self.hello) # 按下按鈕所執行的函數
        photo6 = Button(choose_photo,          # 按鈕所在視窗
                        bg = 'gray',  # 顯示文字
                        command = self.hello) # 按下按鈕所執行的函數
        # 以預設方式排版按鈕
        photo1.place(x=0,y=0,width=100,height=100)
        photo2.place(x=100,y=0,width=100,height=100)
        photo3.place(x=200,y=0,width=100,height=100)
        photo4.place(x=0,y=100,width=100,height=100)
        photo5.place(x=100,y=100,width=100,height=100)
        photo6.place(x=200,y=100,width=100,height=100)  

    
    def back(self):
        self.face1.destroy()
        initface(self.master)
        
    
if __name__ == '__main__':    
    root = Tk()
    basedesk(root)
    root.mainloop()